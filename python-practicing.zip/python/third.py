# import numpy as np

# arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])
# print(arr[1]+[8])

# arr = np.array([[1, 2, 3, 4, 5], [6, 7, 8, 9, 10]])

# print('2nd element on 1st row: ', arr[0, 1])

# arr = np.array([1, 2, 3, 4, 5, 6])
# print(arr[1:5])


# arr = np.array([1, 2, 3, 4, 5, 6])
# print(arr[4:])


# newtype = np.array([1, 2, 3, 4, 5, 6, 78, 78, 6, 456, 465, 465, ])

# print(newtype.dtype)


# x = np.array([1.1, 2.1, 3.1])

# y = x.astype("i")
# print(y)
# print(y.dtype)


# arr = np.array([1, 0, 3])

# newarr = arr.astype(bool)

# print(newarr)
# # print(newarr.dtype)
# # %%
# # %%
# import numpy as numpy
# arr = numpy.array([1, 0, 3])

# newarr = arr.astype(bool)

# print(newarr)
# print(newarr.dtype)

# import numpy as numpy

# arr = numpy.array([1, 2, 3, 4, 5, 6, 7])
# x = arr.copy()
# arr[0] = 424
# print(arr)
# print(x)

# newarr = numpy.array([1, 2, 3, 4, 5, 6, 7])

# x = arr.view()
# arr[0] = 4555
# print(newarr)
# print(x)

# newarr = numpy.array([1, 2, 3, 4, 5, 6, 7])

# y = arr.view()
# arr[0] = 231
# print(newarr)
# print(y)

# gem = numpy.array([1, 2, 6, 4, 8, 7, 9])

# f = gem.copy()
# d = gem.view()

# print(f.base)
# print(d.base)

# check = numpy.array([[1,2,3,4,5,6,7,8,9], [1,2,3,4,5,6,7,8,9]])

# print(check.shape)

# import numpy as numpy

# arr = numpy.array([1, 2, 3, 4, 5, 6, 7,8,9,10,11,12,13,14,15,16,17,18,])

# newarr = arr.reshape(4 , 3)

# print(newarr)


# arr = numpy.array([1, 2, 3, 4, 5, 6, 7, 8, 9, 10,
#                   11, 12, 13, 14, 15, 16, 17, 18, ])

# newarr = arr.reshape(4, 3, 2)

# print(newarr)

# yes = numpy.array([1, 2, 3, 4, 5, 6, 7, 8])

# print(yes.reshape(2, 4).base)

# arr  = numpy.array([1, 2, 3, 4, 5,])

# x = arr.reshape(2,4,-1)
# print(x)


# newarr = numpy.array([[1,2,3,4,5,6,7,8,9],[1,2,3,4,5,6,7,8,9]])

# y = newarr.reshape(-4)
# print(y)

# arr1d = numpy.array([4,5,458,74,54,4121,231,3,132 ])

# for x in arr1d:
#     print(x)


# arr2d = numpy.array([[4,5,458,74,54,4121,231,3,132 ],[4,5,458,74,54,4121,231,3,132 ]])

# for y in arr2d:
#     print(y)

# arr = numpy.array([[[1, 2], [3, 4]], [[5, 6], [7, 8]]])

# for x in numpy.nditer(arr):
#     print(x)

# arr = numpy.array([[[1, 2], [3, 4], [5, 6]]])

# for x in numpy.nditer(arr):
#     print(x)


# ndier = numpy.array([[[1, 2], [3, 4]]])

# for x in numpy.nditer(ndier, flags=['buffered'],  op_dtypes=['S']):
#     print(x)


# arr = numpy.array([[12, 1, 2, 45, 5, 45]])

# for x in numpy.nditer(arr[:, ::2]):
#     print(x)

# arr = numpy.array([[12,1,21,231,3,1351,63,],[121,2,15,1,6514,56,4156,16,1]])

# for idx, x in enumerate(arr):
#     print(idx,x)

# username = input("Enter Username:")
# print("your user name is " + username)
import numpy as np
# arr1 = np.array([1, 2, 3])

# arr2 = np.array([4, 5, 6])
# arr = np.concatenate((arr1 , arr2))
# print(arr)

# arr1 = np.array([[1, 2], [3, 4]])

# arr2 = np.array([[5, 6], [7, 8]])

# arr = np.concatenate((arr1, arr2), axis=1)
# print(arr)

# arr1 = np.array([1,2,3])

# arr2 = np.array([4,5,6])

# arr = np.stack((arr1, arr2), axis=1)
# print(arr)


# arr = np.array([1,2,3,4,5,6,7,8,9])
# newarr = np.array_split(arr , 3)
# print(newarr)
# arr = np.array([[1, 2, 3], [4, 5, 6], [7, 8, 9], [10, 11, 12], [13, 14, 15], [16, 17, 18]])

# newarr = np.array_split(arr, 3)

# print(newarr)

# arr = np.array([1, 2, 3, 4, 5, 6, 7, 8, 9])

# arr1 = np.where(arr == 4)
# print(arr1)


# x = np.array([1, 2, 3, 4, 5])
# y = np.where(arr%2 ==0)

# print(y)

# g = np.array([7,8,9])
# e = np.searchsorted(g,7)

# print(e)

# arr = np.array([True,False,True])
# print(np.sort(arr))
