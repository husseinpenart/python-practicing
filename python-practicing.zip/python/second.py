# from calendar import c


# def newFunction():
#     print("Hello next python part")


# newFunction()
# ################################################################


# def FunctionCode(fname):
#     print(fname + " of Hussein Asadi ")


# FunctionCode("Email")
# FunctionCode("Code")
# FunctionCode("Type")


# # lambada
# def x(code): return code + 10


# print(x(5))


# def y(a, b, c): return a*b*c


# print(y(55, 666, 478))


# # def myfunc(n):
# #   return lambda a : a * n

# # mydoubler = myfunc(2)

# # print(mydoubler(11))

# def Func(n):

#     return lambda a: a*n


# mydoubler = Func(2500)


# print(mydoubler(11))


# Array
# from pydoc import classname
# from typing_extensions import Self


# cars = ["Ford", "Volvo", "BMW"]
# # # x = cars[0]
# # # print(x)
# # cars[0] = "Toyota"
# # print(cars)
# # x = len(cars)
# # print(x)
# # for x in cars:
# #     print(x)
# cars.append("Mercedes Benz")
# print(cars)
# cars.pop(1)
# print(cars)


# Method	Description
# append()	Adds an element at the end of the list
# clear()	Removes all the elements from the list
# copy()	Returns a copy of the list
# count()	Returns the number of elements with the specified value
# extend()	Add the elements of a list (or any iterable), to the end of the current list
# index()	Returns the index of the first element with the specified value
# insert()	Adds an element at the specified position
# pop()	Removes the element at the specified position
# remove()	Removes the first item with the specified value
# reverse()	Reverses the order of the list
# sort()	Sorts the list

# class and object

# class MyClass:
#     x = 5


# print(MyClass)


# class newClass:
#     x = 454546


# p1 = newClass
# print(p1.x)


# class Person:
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age


# p2 = Person("John", 25)
# print(p2.name)
# print(p2.age)


# class Person:
#     def __init__(self, name, age):
#         self.name = name
#         self.age = age

#     def myfunc(self):
#         print("Hello my name is " + self.name)


# p1 = Person("Hussein", 26)
# p1.myfunc()

# class person:

#     def __init__(self, fname, lname):
#         self.firstname = fname
#         self.lastname = lname

#     def printname(self):
#         print(self.firstname, self.lastname)


# x = person("Hussein ", "Asadi")
# x.printname()

# class person:

#     def __init__(self, fname, lname):

#         self.firstname = fname
#         self.lastname = lname

#         def printname(self):
#             print(self.firstname, self.lastname)


# class student(person):
#     pass


# x = student("Hussein ", "Asadi")
# x.printname()
##########################################################################
# iterate = ["Multiaction", "Nomberation", "Motivation"]
# myit = (iter(iterate))

# print(next(myit))
# print(next(myit))
# print(next(myit))

# iterat = ["Multiaction", "Nomberation", "Motivation"]

# for x in iterat:
#     print(x)


# class MyNumbers:
#   def __iter__(self):
#     self.a = 1
#     return self

#   def __next__(self):
#     x = self.a
#     self.a += 1
#     return x


# myclass = MyNumbers()
# myiter = iter(myclass)

# print(next(myiter))
# print(next(myiter))
# print(next(myiter))
# print(next(myiter))
# print(next(myiter))

##########################################################################
# importing


# import mymodule

# mymodule.greeting("Hussein")

# import first

# first.firstitem
# import mymodule

# a = mymodule.person1["age"]
# print(a)

# import mymodule as mx

# a = mx.person1["name"]
# print(a)

# import platform

# sys = platform.system()

# print(sys)

# import winnt

# y = dir(winnt)

# print(y)

# from mymodule import person1

# print(person1["age"])

# import datetime

# x  = datetime.datetime.now()
# print(x)


# import datetime

# print(x.year)
# print(x.strftime("%B"))
# import datetime

# print(x.year)
# print(x.strftime("%A"))
# import datetime

# print(x.year)
# print(x.strftime("%H"))
# import datetime

# print(x.year)
# print(x.strftime("%Y"))
# import datetime

# print(x.year)
# print(x.strftime("%I"))

# x = min(45,4,87498,7498,1,456,12,2)
# y = max(45646,4,545,341654,48,45,64,564,654,564,564,564,465,4,5646,8468,74)
# print(x,y)


# f = pow(550,2225)

# print(f)

# import math

# x = math.sqrt(56565)
# print(x)

# import math
# a = math.ceil(524)
# b = math.floor(41545.22312115)

# for x in a,b:
#     print(x)

# import math
# x = math.pi(3.14)
# print(x)
# import json

# x = '{"name":"Hussein","lastname":"Asadi","age "; 35}'
# y = json.dumps(x)

# print(y["age"])


# from distutils.filelist import findall
# import re

# txt = "The rain in Spain"
# x = re.search("^The.*Spain$", txt)
# if x:
#     print("Yes WE Fount a match " + " \292")
# else:
#     print("Noooo we Didnt find any match " + " \295")
# import re
# txt = "Rain is Comming in Spain For Two Hours"
# x = re.findall("s", txt)
# print(x)


# txt = "The rain in Spain"
# x = re.search("\s", txt)

# print("The first white-space character is located in position:", x.start())

# from pandas import NamedAgg


# try:
#     print(x)
# except:
#     print("This is a Error occure")

# try:
#     print(c)
# except NameError:
#     print("An error accured for once a time please fix that")
# except:
#     print("This is error is for misspelling please fix the bug")

# try:
#     print("Hello")
# except:
#     print("Somthing goes wrong please fix that")
# else:
#     print("Somthing is true")

# try:
#     print(x)
# except:
#     print("An error occured on this step"  + " \2 " )
# finally:
#     print("This Bug fixed finally and we are Done " + "\1")
##########################################################################
# USer Input

# username = input("Enter Your username plz" + "  \1")
# if username== str:
#     print("username is " + username)
# else:
#     print("Your user name is not string please fix that")
# from traceback import print_tb


# price = "49$"
# txt = "This price is {} much expensive for me"
# print(txt.format(price))
##########################################################################

# file handeling for web application
# f = open('index.html', "r")

# print(f.read() )
# o = open("C:\xampp\htdocs\index.php" , "r")
# print(o.readline())

# r = ("first.py"  , "r")

# print(r.read())

# r = open("demon.txt" , "r")

# print(r.read())


# x = open("demon.txt" ,  "r")

# print(x.readline())
# x.close()

# from asyncore import write


# f = open("demon.txt2" , "a")
# f.write("THis is a test")
# f.close()

# f = open("demon.txt2" , "r")
# print(f.read())

# f = open("demon.txt3", "a")
# f.write("this is a another part of demon file.txt")
# f.close()

# f = open("demon.txt3", "r")
# print(f.read())

# import os
# f = open("demon.txt3", "w")
# f.write("This is another line")
# f.close()

# f = open("demon.txt3", "r")
# print(f.read())


# if os.path.exists("demon.txt"):
#     os.remove("demon.txt")

# else:

#     print("This file does not exist ")


# if os.path.exists("demon.text"):
#     os.remove("demon.text")

# else:

#     print("This file does not exist ")
##########################################################################
# numpy
import numpy as np
# arr = [1,2,3,4,5,5,8,8,74,7,]
# print(arr)

# print(np.__version__)

# newarr = [1,2,3,4,5,5,8,8,74,7,]

# print(newarr)
# print(type(newarr))
# d0 = np.array(45)
# print(d0)

# d1 = np.array([1,5,5,4,4,8,4,4,36,4,541,6345,87486,])
# print(d1)
# d2 = np.array([[1,2,3] , [4,5,6]])
# print(d2)
# d3 = np.array([[[1,2,3] , [4,5,6,], [7,8,9] , [5,4,8]]])
# print(d3)

a = np.array(45)
b = np.array([1, 5, 5, 4, 4, 8, 4, 4, 36, 4, 541, 6345, 87486, ])
c = np.array([[1, 2, 3], [4, 5, 6]])
d = np.array([[[1, 2, 3], [4, 5, 6, ], [7, 8, 9], [5, 4, 8]]])
print(a.ndim)
print(b.ndim)
print(c.ndim)
print(d.ndim)


arr = np.array([1, 2, 3, 4], ndmin=5)
print(arr)
print("The dimension :", arr.ndim)
