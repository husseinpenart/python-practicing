# import numpy as np

# arr = np.array([41, 42, 43, 44])

# filter_arr = []

# for element in arr:
#     if element > 42:
#         filter_arr.append(True)
#     else:
#         filter_arr.append(False)

# newarr = arr[filter_arr]

# print(filter_arr)
# print(newarr)
# from numpy import random
# x = random.randint(100)
# print(x)

# y = random.rand()
# print(y)
# x  = random.randint(100, size=(10))
# print(x)
# x = random.choice([5,8,1,9,3])
# print(x)
# import numpy as np
# x = random.choice([3, 5, 7, 9], p=[0.1, 0.3, 0.6, 0.0], size=(100))
# print(x)

# x = np.choice([3, 5, 7, 9])
# random.shuffle(x)
# print(x)
# arr = np.array([1, 2, 3, 4, 5])

# print(random.permutation(arr))


# import matplotlib.pyplot as plt
# import seaborn as sns

# sns.distplot([0, 1, 2, 3, 4, 5] , hist=False)

# plt.show()

# import matplotlib.pyplot as plt
# import seaborn as sns

# sns.distplot([0, 1, 2, 3, 4, 5,6,7,8,9] , hist=False)

# plt.show()
# from numpy import random

# arr = random.normal(loc=1, scale=2, size=(2, 3))
# print(arr)
# import matplotlib.pyplot as plt
# import seaborn as sns

# sns.distplot(random.normal(size=1000), hist=False)

# plt.show()

# from numpy import random

# x = random.binomial(n=10, p=0.5, size=10)
# print(x)

# from numpy import random
# import matplotlib.pyplot as plt
# import seaborn as sns

# sns.distplot(random.normal(loc=50, scale=5, size=1000),
#              hist=False, label='normal')
# sns.distplot(random.binomial(n=100, p=0.5, size=1000),
#              hist=False, label='bionomical')

# plt.show()

# sns.distplot(random.binomial(n=10, p=0.5, size=1000), hist=True, kde=False)

# plt.show()

# sns.distplot(random.uniform(size=1000), hist=False)
# plt.show()

# import numpy as np
# x = [1, 2, 3, 4, 5, 6]
# y = [7, 8, 9]
# z = []
# for i ,j in zip(x, y):
#     z.append(i+j)
#     print(z)

# def myadd(x, y):
#     return x + y
# myadd = np.frompyfunc(myadd , 1,2)
# print(myadd, [1,2,3,4,5,6], [1,2,3,4,5,6], [1,2,3,4,])

# print(type(np.add))
# print(type(np.concatenate))


# arr1 = ([1,2,3,4,45,87,])
# arr2 = ([5,484,863,4156,416,44,])
# x = np.add(arr1 , arr2)
# print(x)


# arr3 = ([1,2,3,4])
# arr4 = ([6,7,8,9])
# xx = np.subtract(arr3 , arr4)
# print(xx)
# arr5 = np.array([10, 20, 30, 40, 50, 60])
# arr6 = np.array([20, 21, 22, 23, 24, 25])
# xxx = np.multiply(arr5 , arr6)
# print(xxx)
# arr7= np.array([10, 20, 30, 40, 50, 60])
# arr8 = np.array([20, 21, 22, 23, 24, 25])
# xxx = np.divide(arr7 , arr8)
# print(xxx)
# arr9 = np.array([10, 20, 30, 40, 50, 60])
# arr0 = np.array([20, 21, 22, 23, 24, 25])
# xxx = np.power(arr9 , arr0)
# print(xxx)
# arr10 = np.array([10, 20, 30, 40, 50, 60])
# arr11 = np.array([20, 21, 22, 23, 24, 25])
# xxx = np.mod(arr10 , arr11)
# print(xxx)
# arr12 = np.array([10, 20, 30, 40, 50, 60])
# arr13 = np.array([20, 21, 22, 23, 24, 25])
# xxx = np.divmod(arr10 , arr11)
# print(xxx)
# arr14 = np.array([10, 20, 30, 40, 50, 60])
# arr15 = np.array([20, 21, 22, 23, 24, 25])
# xxx = np.absolute(arr14 , arr15)
# print(xxx)

# import numpy as np
# arr = ([-3.15255, 3.5543])

# x = np.trunc(arr)
# print(x)
# arr1 = ([-3.15255, 3.5543])

# xx = np.fix(arr1)
# print(xx)
# arr2 = ([-3.15255, 3.5543])

# xx = np.around(arr2)
# print(xx)
# arr3 = ([-3.15255, 3.5543])

# xx = np.floor(arr3)
# print(xx)
# arr4 = ([-3.15255, 3.5543])

# xx = np.ceil(arr4)
# print(xx)\


# import numpy as np

# x = np.arange(1,10)
# print(np.log2(x))

# arr = np.arange(1,10)

# print(np.log10(arr))
# arr = np.arange(1,10)

# print(np.log(arr))

# import numpy as np
# from math import log

# nplog = np.frompyfunc(log, 2, 1)
# print(nplog(100, 15))

# arr1 = np.array([1, 2, 3])
# arr2 = np.array([1, 2, 3])

# newarr = np.sum([arr1, arr2])

# print(newarr)

# nmsum = ([1,2,34,5])
# x = np.cumsum(nmsum)
# print(x)

# import numpy as np
# arr = np.array(["new","old","fresh"])
# x = np.prod(arr)
# print(x)
# arr1 = np.array([1, 2, 3, 4])
# arr2 = np.array([5, 6, 7, 8])
# x = np.prod([arr1, arr2])
# print(x)
# arr = np.array([5, 6, 7, 8])
# newarr = np.cumprod(arr)
# print(newarr)
# import numpy as np
# arr = np.array([54,21,54,87,98,84,98484,854,94,894,98,498])
# x = np.diff(arr)
# print(x)
# arr = np.array([54,21,54,87,98,84,98484,854,94,894,98,498])
# x = np.diff(arr , n=2)
# print(x)
# import numpy as np
# num1 = 4
# num2 = 6

# x = np.lcm(num1, num2)

# print(x)

# arr = np.array([3, 6, 9])

# x = np.lcm.reduce(arr)

# print(x)


# num1 = 6
# num2 = 9

# x = np.gcd(num1, num2)

# print(x)

# arr = np.array([20, 8, 32, 36, 16])

# x = np.gcd.reduce(arr)

# print(x)

# import numpy as np
# x = np.sin(np.pi/2)
# print(x)
# arr = np.array([np.pi/2, np.pi/3, np.pi/4, np.pi/5])
# x = np.sin(arr)
# print(x)
# y = np.array([12, 15, 4, 54, 854, 89498])
# v = np.deg2rad(y)
# print(v)
# arr = np.array([np.pi/2, np.pi, 1.5*np.pi, 2*np.pi])

# x = np.rad2deg(arr)

# print(x)
# arr = np.array([1, -1, 0.1])

# x = np.arcsin(arr)

# print(x)
# base = 3
# perp = 4

# x = np.hypot(base, perp)

# print(x)
import numpy as np

x = np.sinh(np.pi/2)

print(x)

arr = np.array([np.pi/2, np.pi/3, np.pi/4, np.pi/5])

x = np.cosh(arr)

print(x)