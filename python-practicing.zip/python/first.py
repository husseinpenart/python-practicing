# # p = 1
# # x = 1.22
# # y = "this is a string"
# # print(type(p))
# # print(type(x))
# # print(type(y))


# # b = "Movement Range"

# # print((b[2:5]))


# # uppercase = "uppercase in python"
# # print(uppercase.upper())

# # lowercase = "THIS IS A LOWER CASE "
# # print(lowercase.lower())

# # s = " this is a "
# # print(s.strip())

# # a = "jove you"
# # print(a.replace("j", "l"))

# # h = "I know you right python i want you"
# # print(h.split())

# # age = 55
# # txt = "My name is Ahmad and im", age, "years old"
# # print(txt)

# # wife = "Ahmad's wife"
# # text = "Hello my name is Leila ,{}  "
# # print(text.format(wife))

# # esm = "Programming language "
# # learn = "python language "
# # to = " to learn new languages "
# # result = "Hi my name is Hussein  and i want to learn a ,{2} , and i think ,{0}, is good , but i want ,{1}"
# # print(result.format(esm, learn, to))

# # esm = "Programming language "
# # learn = "python language "
# # to = " to learn new languages "
# # result = "Hi my name is Hussein  and i want to learn a ,{} , and i think ,{}, is good , but i want ,{}"
# # print(result.format(esm, learn, to))

# # print("This is a programming \"python\"you can enjoy it")
# # numb = "\632"
# # print(numb)


# # capitalize	Converts the first character to upper case
# # casefold()	Converts string into lower case
# # center()	Returns a centered string
# # count()	Returns the number of times a specified value occurs in a string
# # encode()	Returns an encoded version of the string
# # endswith()	Returns true if the string ends with the specified value
# # expandtabs()	Sets the tab size of the string
# # find()	Searches the string for a specified value and returns the position of where it was found
# # format()	Formats specified values in a string
# # format_map()	Formats specified values in a string
# # index()	Searches the string for a specified value and returns the position of where it was found
# # isalnum()	Returns True if all characters in the string are alphanumeric
# # isalpha()	Returns True if all characters in the string are in the alphabet
# # isdecimal()	Returns True if all characters in the string are decimals
# # isdigit()	Returns True if all characters in the string are digits
# # isidentifier()	Returns True if the string is an identifier
# # islower()	Returns True if all characters in the string are lower case
# # isnumeric()	Returns True if all characters in the string are numeric
# # isprintable()	Returns True if all characters in the string are printable
# # isspace()	Returns True if all characters in the string are whitespaces
# # istitle()	Returns True if the string follows the rules of a title
# # isupper()	Returns True if all characters in the string are upper case
# # join()	Joins the elements of an iterable to the end of the string
# # ljust()	Returns a left justified version of the string
# # lower()	Converts a string into lower case
# # lstrip()	Returns a left trim version of the string
# # maketrans()	Returns a translation table to be used in translations
# # partition()	Returns a tuple where the string is parted into three parts
# # replace()	Returns a string where a specified value is replaced with a specified value
# # rfind()	Searches the string for a specified value and returns the last position of where it was found
# # rindex()	Searches the string for a specified value and returns the last position of where it was found
# # rjust()	Returns a right justified version of the string
# # rpartition()	Returns a tuple where the string is parted into three parts
# # rsplit()	Splits the string at the specified separator, and returns a list
# # rstrip()	Returns a right trim version of the string
# # split()	Splits the string at the specified separator, and returns a list
# # splitlines()	Splits the string at line breaks and returns a list
# # startswith()	Returns true if the string starts with the specified value
# # strip()	Returns a trimmed version of the string
# # swapcase()	Swaps cases, lower case becomes upper case and vice versa
# # title()	Converts the first character of each word to upper case
# # translate()	Returns a translated string
# # upper()	Converts a string into upper case
# # zfill()

# # from os import access
# # from pydoc import Doc
# # from types import TracebackType

# # from numpy import true_divide


# # g = Doc == + 55
# # print(g)
# # x = "\155"
# # y = "\255"
# # if x > y:
# #     print(True)
# # else:
# #     print(False)

# # print(bool("mdlksajkljaskljfdaklsjfd;as"))
# # print(bool(-45674654564654))
# # print(bool(TracebackType))


# # def Function():
# #     return True


# # print(Function())


# # def newtable():
# #     return True


# # if newtable:
# #     print("YEahhhhhhhhhhhhhhhhh")
# # else:
# #     print("noooooooooooooooooooooooooooooooooo")

# # e = 55
# # print(isinstance(x, int))

# # list = ["me", "you", "they"]
# # print(len(list))

# # datatype = ["me", "you", "they", 54564, 1.424, True, False]

# # print(type(datatype))


# # access = ["me", "you", "they", 54564, 1.424, True, False]
# # print(access[2])

# # access1 = ["me", "you", "they", 54564, 1.424, True, False]
# # if 54564 in access1:
# #     print("Yes its in field array")
# # else:
# #     print("especific word is empty")
# # print(access1[-2:3])

# # # changing and replacing for data science
# # access2 = ["me", "you", "they", 54564, 1.424, True, False]
# # access2 [0:2] = ["Hussein" , "Alexander"]
# # print(access2)
# # access3 = ["me", "you", "they", 54564, 1.424, True, False]
# # access3.insert(3 ,"Sara" )
# # print(access3)
# # access4 = ["me", "you", "they", 54564, 1.424, True, False]
# # access4.append("Motivation" )
# # print(access4)
# # access5 = ["first" , 54564165, "second" , True , False , 565546546]
# # access5.extend(access4)
# # print(access5)
# # access6 = ["first" , 54564165, "second" , True , False , 565546546]
# # access6.pop(1)
# # print(access6)
# # access7 = ["first" , 54564165, "second" , True , False , 565546546]
# # del access7[0]
# # print(access7)
# # access8 = ["first" , 54564165, "second" , True , False , 565546546]
# # access8.clear()
# # print(access8)

# # # Looping
# # # access9 = ["first" , 54564165, "second" , True , False , 565546546]
# # # for x in access9 :
# # #  print(x)

# # access10 = ["first" , 54564165, "second" , True , False , 565546546]
# # for i in range(len(access10)) :
# #  print(access10[i])

# # from os import scandir
# # c = scandir, "https://www.digiforklift.com"
# # print(c)

# # array = ["first" , 54564165, "second" , True , False , 565546546, "me", "you", "they", 54564, 1.424, True, False ]

# # # i = 0
# # # while i < len(array):
# # #     print(array[i])
# #  i  = i+ 1
# # array = ["first", 54564165, "second", True, False, 565546546,
# #          "me", "you", "they", 54564, 1.424, True, False]
# # [print((x) for x in array)]

# # array1 = ["first", 54564165, "second", True, False,
# #           565546546, "me", "you", "they", 54564, 1.424, True, False]
# # newarray = []

# # for x in array1:
# #     if "you" in array1:
# #         newarray.append(x)
# #         print(newarray)

# # array1 = ["first",  "second",
# #           "me", "you", "they"]
# # newarray = [x for x in array1 if "e" in x]
# # print(newarray)
# # array1 = ["first",  "second",
# #           "me", "you", "they"]
# # newlist = [ x if x != "second" else "third" for x in array1]


# # array1 = ["first",  "second",
# #           "me", "you", "they"]
# # array1.sort()
# # print(array1)
# # array1 = ["first",  "second",
# #           "me", "you", "they"]
# # array1.sort(reverse= True)
# # print(array1)

# # number = [4154,21,45,645,4523,1546456456,1,2,4,8,6,7,123,874,4,13,3,0,5,48,4545,]
# # number.sort()
# # print(number)
# # def func(n):
# #   return abs(n - 50)
# # thislist  = [454,85,456,46,4,654,564,654,65,4,654]
# # thislist.sort(key = func)
# # print(thislist)

# # thisnumb = ["Orange", "apple", "Banana" , "cucumber" , "Hash"]
# # thisnumb.sort()
# # print(thisnumb)
# # thisnumb = ["Orange", "apple", "Banana" , "cucumber" , "Hash"]
# # thisnumb.sort(key= str.lower)
# # print(thisnumb)

# # thisnumb = ["Orange", "apple", "Banana", "cucumber", "Hash"]
# # newlist = list(thisnumb)
# # print(newlist)


# # # Dictionaries

# # dic = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }

# # print(dic)
# # #################################################################

# # dicget = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # x = dicget.get("brand")
# # print(x)
# # #################################################################
# # dickey = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # y = dickey.keys()
# # print(y)
# # #################################################################
# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # y = dicchange.keys()
# # print(y)
# # dicchange["Color"] = "Blue"
# # print(y)
# # #################################################################
# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # y = dicchange.values()
# # print(y)
# # dicchange["style"] = "Classic", 1998
# # print(y)
# # #################################################################
# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # y = dicchange.items()
# # print(y)
# # dicchange["Topic"] = "Modern car in", 1998
# # print(y)
# # #################################################################
# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # message = "encongreed field is in list"
# # error = "encongredd field is no in list"

# # if "company" in dicchange:
# #     print(message)
# # else:
# #     print(error)
# #################################################################
# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }

# # dicchange.update({"year": 2020})
# # print(dicchange)
# # #################################################################
# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # for x in dicchange:
# #  print(dicchange[x])
# #  #################################################################

# # dicchange = {
# #     "model": "charted",
# #     "year": 1995,
# #     "brand": "Ford",
# #     "company": "Ford"

# # }
# # newdic = dicchange.copy()
# # print(newdic)
# #################################################################
firstitem = {
    "name": "Hussein ",
    "lastname": "Asadi"
}
seconditem = {
    "email": "artistpenman@gmail.com",
    "Database usage": "MongoDB"
}
thirditem = {
    "Job": "full stack developer",
    "Level": "Senior"
}
fourthitem = {
    "expertaion": "A.I",
    "Tree": "Machine Learning"
}
fifthitem = {
    "age": 26,
    "degree": "Full"
}

background = {
    "firstitem": "firstitem",
    "seconditem": "seconditem",
    "thirditem": "thirditem",
    "fourth": "fourthitem",
    "fifthitem": "fifthitem"
}

print(firstitem, seconditem, thirditem, fourthitem, fifthitem)
# #################################################################
# # if elif else
# a = 55
# b = 65666
# if b == a:
#     print("These element are equal")
# elif a < b:
#     print("This is a greater one")
# else:
#     print("Equal or greater is not same")
# #################################################################

# i = 1
# while i < 6:
#     if i >= 6:
#   continue
#     # elif i< 6:
#         print(True)
# else:
#     print(False)

x = '\432'
print(x)